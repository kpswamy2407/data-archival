package settings

//Logpath is used to store the archival log for the application
const Logpath = "D:/work/go/src/github.com/kpswamy540/db.archive.system/logs/"

//ConfigUploadPath is used to store the configurations in the path
const ConfigUploadPath = "D:/work/go/src/github.com/kpswamy540/db.archive.system/temp/"
